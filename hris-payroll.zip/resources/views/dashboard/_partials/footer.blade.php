<footer class="main-footer">
    <div class="footer-left">
        <i class="fas fa-copyright"></i> {{ date('Y') }} {{ config('app.name') }}
        <div class="bullet"></div>
        Developed by @IT Saloka Application
    </div>
    <div class="footer-right">
        1.1.4
    </div>
</footer>
