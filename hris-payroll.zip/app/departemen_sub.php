<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class departemen_sub extends Model
{
    protected $table = 'departemen_sub';
}
