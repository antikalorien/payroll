<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class c_hutangPerusahaan_anggota extends Controller
{
    //
}
