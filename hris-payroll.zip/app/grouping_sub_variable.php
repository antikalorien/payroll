<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class grouping_sub_variable extends Model
{
    protected $table = 'grouping_sub_variable';
    protected $fillable = ['id'];
    public $incrementing = false;
}
