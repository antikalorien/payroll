<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class skema_hari_kerja extends Model
{
    protected $table = 'skema_hari_kerja';
}
