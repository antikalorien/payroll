<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gaji_thr_variable extends Model
{
    protected $table = 'gaji_thr_variable';
}
