<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class periode_jadwal extends Model
{
    protected $table = 'periode_jadwal';
}
