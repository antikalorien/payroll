<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class group_sub_variable extends Model
{
    protected $table = 'group_sub_variable';
    protected $fillable = ['id'];
    public $incrementing = false;
}
