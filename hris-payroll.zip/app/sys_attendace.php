<?php

namespace App;


use Illuminate\Database\Eloquent\Model;

class sys_attendace extends Model
{
    protected $table = 'sys_attendace';
}
