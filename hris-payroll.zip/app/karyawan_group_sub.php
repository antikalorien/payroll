<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class karyawan_group_sub extends Model
{
    protected $table = 'karyawan_group_sub';
    protected $fillable = ['id'];
    public $incrementing = false;
}
