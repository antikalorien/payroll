<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gaji_lembur extends Model
{
    protected $table = 'gaji_lembur';
}
