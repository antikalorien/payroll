<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class kehadiran_absensi extends Model
{
    protected $table = 'kehadiran_absensi';
}
