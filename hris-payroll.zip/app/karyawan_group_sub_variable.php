<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class karyawan_group_sub_variable extends Model
{
    protected $table = 'karyawan_group_sub_variable';
    protected $fillable = ['id'];
    public $incrementing = false;
}
