<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class karyawan_group_sub_variable_bpjs extends Model
{
    protected $table = 'karyawan_group_sub_variable_bpjs';
    protected $fillable = ['id'];
    public $incrementing = false;
}
