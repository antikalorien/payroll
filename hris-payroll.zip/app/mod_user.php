<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class mod_user extends Model
{
    protected $table = 'users';
    // protected $fillable = ['id','id_departemen','id_departemen_sub','pos','grade','id_absen','username','name','email','password','ho_hp','id_skema_hari_kerja','system','status'];
}